# Graphics Programming 1 - Raytracer

This project contains the start code for the raytracer being built in the first 5 courseweeks of Graphics Programming 1. 

Each week further extensions are made to the raytracer to support objects, lighting, camera movement, ...
